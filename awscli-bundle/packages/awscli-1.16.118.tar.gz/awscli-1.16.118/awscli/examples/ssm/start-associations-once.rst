**To execute an association immediately and only one time**

This example executes the specified association immediately and only once. There is no output if the command succeeds.

Command::

  aws ssm start-associations-once --association-id "8dfe3659-4309-493a-8755-0123456789ab"

